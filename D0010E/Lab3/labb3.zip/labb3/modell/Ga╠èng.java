package labb3.modell;

public class Gång {

	// TODO: Lägg till tillståndsvariabler för att hålla parametrarna till
	// konstruktorn. 

	public Gång(Rum från, Väderstreck riktningUtUrFrån, Rum till,
			Väderstreck riktningInITill) {
		// TODO: Tilldela tillståndsvariablerna parametervärdena.
	}

	// TODO: Lägg till instansmetoder som returnerar tillståndsvariablernas
	// värden.
}
